#import <UIKit/UIKit.h>

@interface UIColor (Tetradic)
@property (copy, readonly, nonatomic) NSArray<UIColor *> *tetradicColors;

@end