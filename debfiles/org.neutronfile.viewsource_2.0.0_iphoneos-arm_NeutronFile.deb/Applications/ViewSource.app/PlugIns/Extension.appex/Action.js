var Action = function() {};

Action.prototype = {

run: function(arguments) {
	var images = document.images;
	var imageUrls = new Array;

	for (var i = 0; i < images.length; ++i) {
		var img = images[i];
		if (img.src == null) continue;
		imageUrls.push(img.src);
	}


	var scripts = document.scripts;
	var scriptUrls = new Array;

	for (var i = 0; i < scripts.length; ++i) {
		var script = scripts[i];
		if (script.src == null) continue;
		scriptUrls.push(script.src);
	}


	var stylesheets = document.styleSheets;
	var stylesheetUrls = new Array;

	for (var i = 0; i < stylesheets.length; ++i) {
		var stylesheet = stylesheets[i];
		if (stylesheet.href == null) continue;
		stylesheetUrls.push(stylesheet.href);
	}



	var links = document.links;
	var linkUrls = new Array;

	for (var i = 0; i < links.length; ++i) {
		var link = links[i];
		if (link.href == null) continue;
		linkUrls.push(link.href);
	}



	function getTree(node) {
		var r = {tag: node.nodeName}, a, i;
		if (node.childElementCount) {
			r.children = [];

			if (node.children == null) {
				return r;
			}

			for (i = 0; a = node.children[i]; i++ ) {
				r.children.push(getTree(a));
			}
		}

		for (i = 0; a = node.attributes[i]; i++) {
			r[a.nodeName] = a.nodeValue;
		}

		return r;
	}

	var tree = getTree(document.documentElement);


	arguments.completionFunction({"URL" : document.URL, "title" : document.title, "images" : imageUrls, "scripts" : scriptUrls, "stylesheets" : stylesheetUrls, "links" : linkUrls, "charSet" : document.characterSet, "cookies" : document.cookie, "lastModified" : document.lastModified, "dom" : getTree(document.documentElement), "pageSource" : document.documentElement.outerHTML});
},

finalize: function(arguments) {
	var customJavaScript = arguments["customJavaScript"];
	eval(customJavaScript)
}

};

var ExtensionPreprocessingJS = new Action
